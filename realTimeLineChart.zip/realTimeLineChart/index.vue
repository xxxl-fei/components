实时折线图（24小时）
<template>
  <div class="chart-wrap">
    <div class="chart" ref="chart"></div>
  </div>
</template>

<script>
/**
 * 后端返回数据格式
 * [{name: ''00:00, value: 100}, {name: '01:00', value: 110}, {name: '02:00', value: 120}, {name: '23:00', value: 200}, {name: '24:00', value: 210}]
 */

export default {
  name: 'RealTimeLineChart',
  props: {
    data: {
      type: Array,
      default: () => []
    },
    // 时间间隔（粒度）一般都是5分钟、10分钟、30分钟、1小时
    interval: {
      type: Number,
      default: 5
    }
  },
  watch: {
    data: {
      handler(newValue) {
        this.data = newValue
        // this.getmax()
        setTimeout(() => {
          this.init()
        }, 500);
      },
      deep: true
    }
  },
  data() {
    return {
      chart: null,
      // xName 是x轴显示的文字
      xName: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00', '24:00'],
      max: 1500,
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    // 排序
    compare(property) {
      return (a, b) => {
        const value1 = a[property];
        const value2 = b[property];
        return value2 - value1;
      }
    },
    getmax() {
      const newArr = this.data.sort(this.compare('value'))
      setTimeout(() => {
        this.max = Number(newArr[0].value)
      }, 200);
    },
    // 绘制折线图
    initData() {
      const xArray = []
      let hour = 0
      let time = 0
      for (let i = 0; i < 24; i += 1) {
        for (let j = 0; j < 60; j += this.interval) {
          hour = i < 10 ? `0${i}` : i
          time = j < 10 ? `0${j}` : j
          xArray.push([`${hour}:${time}`])
        }
      }
      xArray.push(['24:00'])
      return xArray
    },
    changeData(array) {
      const newArray = []
      array.forEach((item) => {
        newArray.push([item.name, item.value])
      })
      return newArray
    },
    init() {
      this.myChart = this.$echarts.init(this.$refs.chart);
      if (this.data && this.data.length > 0) {
        this.myChart.hideLoading()
      }
      this.changeData(this.data)
      this.initChart()
    },
    initChart() {
      const self = this
      const todayOptions = {
        grid: {
          left: '0',
          right: 20,
          top: 10,
          bottom: 0,
          containLabel: true
        },
        xAxis: {
          type: 'category',
          boundaryGap: false, // 坐标轴两边留白
          data: this.initData(),
          axisLabel: { // 坐标轴刻度标签的相关设置。
            textStyle: {
              color: '#fff',
              fontStyle: 'normal',
              fontFamily: '微软雅黑',
              fontSize: 14
            },
            interval: 0,
            formatter(value) {
              let showValue = ''
              if (self.xName.indexOf(value) !== -1) {
                showValue = value
              }
              return showValue;
            }
          },
          axisTick: { // 坐标轴刻度相关设置。
            show: false,
          },
          axisLine: { // 坐标轴轴线相关设置
            lineStyle: {
              color: '#40444d',
            }
          },
          splitLine: { // 坐标轴在 grid 区域中的分隔线。
            show: false,
            lineStyle: {
              color: '#ddd',
            }
          }
        },
        yAxis: [
          {
            type: 'value',
            axisLabel: {
              formatter: (value) => value.toFixed(0),
              textStyle: {
                color: '#fff',
                fontStyle: 'normal',
                fontFamily: '微软雅黑',
                fontSize: 14,
              },
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: '#40444d',
              }
            },
            axisTick: {
              show: false
            },
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed',
                color: '#40444d',
              }
            },
          },
          {
            type: 'value',
            splitLine: {
              show: true,
              lineStyle: {
                width: 1,
                color: '#2f3f5d',
                type: 'dashed'
              }
            },
            axisLine: {
              show: true,
              lineStyle: {
                type: 'dashed'
              }
            },
          }
        ],
        tooltip: {
          trigger: 'axis',
          textStyle: {
            color: '#000',
          }
        },
        series: [
          {
            smooth: false,
            type: 'line',
            symbol: 'none',
            markPoint: {
              symbolSize: 30,
              label: {
                fontSize: 10,
                color: '#fff'
              },
              data: [
                {
                  type: 'max',
                  symbol: 'circle',
                  symbolSize: 12,
                  itemStyle: {
                    color: '#fff'
                  },
                  label: {
                    show: true,
                    distance: 5,
                    color: '#00ffc4',
                    fontWeight: 'bold',
                    fontSize: 16,
                    offset: [0, -18]
                  }
                }
              ]
            },
            itemStyle: {
              color: 'rgb(1,229,182)',
              lineStyle: {
                color: 'rgb(1,229,182)',
                width: 2
              },
            },
            areaStyle: {
              color: {
                type: 'linear',
                x: 0,
                y: 1,
                x2: 0,
                y2: 0,
                colorStops: [{
                  offset: 0, color: 'rgba(5, 248, 184, 0.1)' // 0% 处的颜色
                }, {
                  offset: 1, color: 'rgba(5, 248, 184, 0.7)' // 100% 处的颜色
                }],
                global: false // 缺省为 false
              },
            },
            data: this.changeData(this.data)
          },
        ]
      };
      this.myChart.setOption(todayOptions)
      window.addEventListener('resize', () => {
        this.myChart.resize()
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.chart-wrap {
  width: 100%;
  height: 100%;
  position: relative;
  .chart {
    height: 100%;
  }
}
</style>
