<!--
向上滚动的轮播
carousel的高度小于carousel-container的高度才能滚动
.carousel {
  height: 100px;
}
-->
<template>
  <div class="carousel">
    <div
      class="carousel-container"
      ref="container"
      @mouseover="pause()"
      @mouseout="startScroll()"
    >
      <ul ref="ul">
        <li
          :style="{ height: `${lineHeight}px` }"
          v-for="(item, index) in data"
          :key="index"
        >
          <span v-if="typeof item === 'string'">{{
            `${index + 1}、${item}`
          }}</span>
          <span>{{ item.content }}</span>
        </li>
      </ul>
      <ul ref="ul-virtual" v-show="isScroll">
        <li
          :style="{ height: `${lineHeight}px` }"
          v-for="(item, index) in data"
          :key="index"
        >
          <span v-if="typeof item === 'string'">{{ item }}</span>
          <span>{{ item.content }}</span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Carousel',
  props: {
    data: {
      type: Array,
      default: () => []
    },
    duration: {
      type: Number,
      default: 2000
    },
    // 每次滚动的距离
    scrollGap: {
      type: Number,
      default: 30
    },
    lineHeight: {
      type: Number,
      default: 30
    }
  },
  data() {
    return {
      isScroll: false,
      timer: null
    }
  },
  watch: {
    data() {
      this.startScroll()
    }
  },
  mounted() {
    this.startScroll()
  },
  beforeDestroy() {
    this.clearTimer()
  },
  methods: {
    startScroll() {
      if (this.$refs.ul.offsetHeight < this.$refs.container.offsetHeight) return
      this.isScroll = true
      const parent = this.$refs.container
      const child = this.$refs.ul
      let flag = 0
      this.clearTimer()
      this.timer = setInterval(() => {
        if (parent.scrollTop >= child.scrollHeight) {
          parent.scrollTop = 0
        } else if (
          parent.scrollTop % this.scrollGap === 0 || parent.scrollTop === 0
        ) {
          flag += 1
          if (flag === this.duration / 20) {
            flag = 0
            parent.scrollTop += 1
          }
        } else {
          parent.scrollTop += 1
        }
      }, 20)
    },
    pause() {
      this.clearTimer()
    },
    clearTimer() {
      if (this.timer) clearInterval(this.timer)
    }
  }
}
</script>

<style lang="scss">
.carousel {
  overflow: hidden;
  height: 100px; // 高度根据实际情况来定
  .carousel-container {
    height: 100%;
    overflow-y: scroll;
    margin-right: -17px;
    ul {
      li {
        overflow: hidden;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: left;
        position: relative;
        &:nth-child(2n + 1) {
          background: rgba(11, 106, 156, 0.4);
        }
        &::before {
          content: '';
          display: inline-block;
          width: 6px;
          height: 6px;
          background: #3df0f7;
          border-radius: 3px;
          position: absolute;
          top: 13px;
          left: 8px;
        }
        span {
          margin-left: 20px;
          text-overflow: ellipsis;
          overflow: hidden;
        }
      }
    }
  }
}
</style>
