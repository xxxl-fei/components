实时客流分析
<template>
  <div class="chart-wrap">
    <div class="back-gcolor"></div>
    <div ref="chart" class="passenger-chart"></div>
  </div>
</template>
<script>

export default {
  name: 'LineChart',
  props: {
    data: {
      type: Array,
      default: () => []
    },
  },
  watch: {
    data() {
      this.initChart()
    }
  },
  computed: {
    noDataOption() {
      return this.$store.getters.noDataOption
    }
  },
  data() {
    return {
      days: []
    }
  },
  mounted() {
    this.initChart()
  },
  beforeDestroy() {
    this.myChart && this.myChart.dispose()
  },
  methods: {
    changeData(array) {
      const newArray = []
      array.forEach((item, index) => {
        newArray.push([this.days[index], +item.value])
      })
      return newArray
    },
    initChart() {
      // 基于准备好的dom，初始化echarts实例
      this.myChart = this.$echarts.init(this.$refs.chart);
      if ((this.data && this.data.length > 0)) {
        this.myChart.hideLoading()
      } else {
        this.myChart.showLoading(this.noDataOption)
      }
      this.initLineChart()
    },
    initLineChart() {
      // 指定图表的配置项和数据
      const option = {
        // backgroundColor: 'rgba(9,16,24,0.2)',
        color: ['#3aecf6', '#fb7bcb'],
        tooltip: {
          trigger: 'axis',
          showContent: false,
          axisPointer: {
            type: 'shadow', // line shadow cross
            shadowStyle: {
              color: '#555',
              opacity: 0,
            },
          },
        },
        legend: {
          show: false,
          right: -5,
          icon: 'rect',
          itemWidth: 12,
          itemHeight: 12,
          name: ['实时客流'],
          textStyle: {
            color: '#7bb0c5',
            fontSize: 12,
          },
        },
        grid: {
          x: 0, // 左
          y: 10, // 上
          x2: 20, // 右
          y2: 0, // 下
          containLabel: true
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          interval: 0,
          axisTick: {
            show: false,
          },
          nameTextStyle: {
            // padding: [0, 0, 0, 40],
          },
          axisLabel: {
            show: true,
            color: '#fff',
            fontSize: 14,
            fontFamily: 'Microsoft YaHei',
            margin: 10,
            interval: 0,
            // padding: [0, 0, 0, 40],
            formatter(value) {
              return value
            }
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: '#40444d',
            }
          },
          splitLine: {
            show: false,
            interval: 2,
            lineStyle: {
              color: ['rgba(47,89,146,0.7)']
            }
          },
          splitArea: {
            show: false,
            interval: 0,
            areaStyle: {
              color: ['rgba(47,89,146,0.3)', 'rgba(47,89,146,0.6)']
            }
          },
          // data: this.days // this.data.map((item) => item.name)
          data: this.data.map((item) => item.name)
        },
        yAxis: [{
          splitLine: {
            show: true,
            lineStyle: {
              width: 1,
              color: '#40444d',
              type: 'dashed'
            }
          },
          axisTick: {
            show: false,
          },
          axisLabel: {
            color: '#fff',
            fontSize: 14,
            fontFamily: 'Microsoft YaHei',
            margin: 10
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: '#40444d',
            }
          },
        }, {
          axisTick: {
            show: false,
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: '#40444d',
              type: 'dashed'
            }
          },
        }],
        series: [{
          name: '历史客流',
          type: 'line',
          // smooth: true,
          symbol: 'emptyCircle',
          symbolSize: 10,
          // data: this.changeData(this.data),
          data: this.data.map((i) => i.value),
          itemStyle: {
            color: '#34aaff',
            borderColor: '#34aaff',
            borderWidth: 0,
            opacity: 0
          },
          lineStyle: {
            width: 2,
          },
          areaStyle: {
            color: {
              type: 'linear',
              x: 0, // 右
              y: 0, // 下
              x2: 0, // 左
              y2: 1, // 上
              colorStops: [{
                offset: 0,
                color: 'rgba(27, 183, 255, 0.7)' // 0% 处的颜色
              }, {
                offset: 0.4,
                color: 'rgba(27, 183, 255, 0.1)' // 100% 处的颜色
              }],
              globalCoord: false // 缺省为 false
            }
          },
          emphasis: {
            label: {
              show: true,
              fontSize: 14,
              fontFamily: 'Microsoft YaHei',
              color: '#fff',
              opacity: 1
            },
            itemStyle: {
              color: '#fff',
              borderColor: '#34aaff',
              borderWidth: 2,
              opacity: 1
            }
          }
        }]
      };

      // 使用刚指定的配置项和数据显示图表。
      this.myChart.setOption(option);
    },
    // 获得近7天
    getWeekDay() {
      let temp = [];
      for (let i = 0; i < 15; i += 1) {
        const time = new Date(new Date().setDate((new Date().getDate() + i) - 7));
        // const year = time.getFullYear();
        const month = `0${time.getMonth() + 1}`.slice(-2);
        const strDate = `0${time.getDate()}`.slice(-2);
        temp.push(`${month}-${strDate}`)
      }
      temp = temp.slice(0, 7);
      this.days = temp
    },
  },
}
</script>
<style lang="scss" scoped>
.chart-wrap {
  height: 100%;
  position: relative;
  .passenger-chart{
    width: 100%;
    height: 100%;
  }
}
</style>
