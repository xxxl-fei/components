<template>
  <div class="table-translate">
    <div class="table-wrapper" :class="transName">
      <el-table
        :data="showData"
        fit
        :highlight-current-row="false"
        header-row-class-name="lable-row"
      >
        <el-table-column
          v-for="(item, index) in tableHead"
          align="center"
          :prop="item.property"
          :key="index"
          :label="item.label"
          :width="item.width ? item.width : 'auto'"
        >
          <template slot-scope="scope">
            <span class="no-wrap">
              {{ scope.row[scope.column.property] }}
            </span>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>

export default {
  name: 'TableTranslate',
  props: {
    // table 表头
    tableHead: {
      type: Array,
      default: () => []
    },
    // table 数据
    tableData: {
      type: Array,
      default: () => []
    },
    // 每次显示几行
    // 此属性和外层元素的高度是相关联的
    rows: {
      type: Number,
      default: 1
    }
  },
  data() {
    return {
      transform: 'translate3d(0px, 0px, 0px)',
      allData: [],
      rangeData: [],
      timer: '',
      timerCount: 0,
      showData: [],
      transName: '',
      timersss: '',
      timerss: ''
    }
  },
  mounted() {
    this.refreshData()
  },
  beforeDestroy() {
    this.clearTimer()
  },
  methods: {
    refreshData() {
      this.transName = ''
      this.showData = this.tableData.slice(this.timerCount, this.timerCount + this.rows)
      this.timerCount += this.rows
      const self = this
      this.clearTimer()
      this.timer = setInterval(() => {
        self.transName = 'transform-div'
        self.timersss = setTimeout(() => {
          self.showData = self.tableData.slice(self.timerCount, self.timerCount + this.rows)
          self.timerCount += this.rows
          if (self.timerCount >= self.tableData.length) {
            self.timerCount = 0
          }
          self.transName = ''
        }, 500)
      }, 3000)
    },
    clearTimer() {
      if (this.timer) {
        clearInterval(this.timer)
        this.timer = null
      }
      if (this.timersss) {
        clearTimeout(this.timersss)
        this.timersss = null
      }
    }
  },
}
</script>
<style lang="scss" scoped>
::v-deep.table-translate {
  height: 100px; // 高度根据实际情况来定
  .table-wrapper {
    .td {
      height: 44px;
      line-height: 44px;
    }
    .cell {
      transform-style: preserve-3d;
      transform-origin: 50% 50%;
      transform: rotateX(0deg) rotateY(0deg);
      transition: transform 500ms cubic-bezier(0.15, 0.52, 0.5, 0.9) 0s;
      .no-wrap {
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        overflow: hidden;
      }
    }
  }
  .transform-div {
    .cell {
      transform: rotateX(-80deg) rotateY(0deg);
    }
  }
  .transform-change {
    .cell {
      transform: rotateX(0deg) rotateY(0deg) rotateZ(0deg);
    }
  }
  .el-table,
  .el-table--enable-row-hover .el-table__body tr:hover > td {
    background-color: rgba(0, 0, 0, 0) !important;
  }
  .el-table .lable-row {
    color: #3e90af;
    background-color: rgba(0, 0, 0, 0) !important;
    line-height: 36px;
    .cell {
      width: 100%;
      transform: rotateX(0deg) rotateY(0deg);
    }
  }
  .el-table td,
  .el-table th {
    padding: 0;
    border-bottom: none !important;
  }
  .el-table .lable-row th,
  .el-table .lable-row tr {
    background-color: rgba(0, 0, 0, 0) !important;
  }
  .el-table .el-table__row {
    background-color: rgba(0, 0, 0, 0) !important;
    color: #41eff7 !important;
    &:nth-child(2n + 1) {
      color: #a3b9fd !important;
      background-color: rgba(0, 0, 0, 0.1) !important;
    }
  }
  .el-table--border::after,
  .el-table--group::after,
  .el-table::before {
    background: none !important;
  }
}
</style>
