<template>
  <div class="chart-wrapper">
    <div ref="chart" class="chart"></div>
  </div>
</template>

<script>

export default {
  name: 'Radar',
  props: {
    data: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      max: null,
      arr: [],
      indicatorArr: []
    }
  },
  watch: {
    data() {
      this.getMaxData()
      this.initChart()
    }
  },
  mounted() {
    this.getMaxData()
    this.initChart()
  },
  methods: {
    getMaxData() {
      this.indicatorArr = []
      this.arr = []
      this.data.forEach((dataItem) => {
        this.arr.push(dataItem.value);
        this.indicatorArr.push({
          name: dataItem.name,
          max: 0
        })
      })
      this.max = Math.max(...this.arr) / 0.9
      this.data.forEach((dataItem, index) => {
        this.indicatorArr[index].max = this.max
      })
    },
    initChart() {
      this.chart = this.$echarts.init(this.$refs.chart)
      const option = {
        tooltip: {
          trigger: 'axis'
        },
        grid: {
          top: 100,
          bottom: 20
        },
        radar: [{
          splitNumber: 3,
          indicator: this.indicatorArr,
          name: {
            formatter(values) {
              if (values.length > 7) {
                const show = values.split('')
                values = `${show.slice(0, 6).join('')}\n${show.slice(6, values.length).join('')}`
              }
              return values
            },
            color: '#7bb0c5',
            fontSize: 12
          },
          splitArea: {
            show: true,
            areaStyle: {
              color: ['rgba(114, 172, 209, 0)',
                'rgba(29, 159, 248, 0.3)', 'rgba(114, 172, 209, 0)',
                'rgba(114, 172, 209, 0.8)', 'rgba(114, 172, 209, 1)'],
            },
          },
          splitLine: {
            show: true,
            lineStyle: {
              width: 1.5,
              // type: 'dotted',
              color: ['rgba(114, 172, 209, 0)', 'rgba(114, 172, 209, 0)', 'rgba(114, 172, 209, 0)', 'rgba(14, 245, 255, 0.7)'], // 设置网格的颜色
            },
          },
          radius: 110,
          center: ['50%', '55%'],
          axisLine: {
            lineStyle: {
              type: 'dotted',
              color: 'rgba(14, 245, 255, 0.5)',
            },
          },
        }],
        series: [
          {
            type: 'radar',
            areaStyle: {},
            data: [
              {
                value: this.arr,
                name: '指数',
                symbol: 'circle',
                lineStyle: {
                  color: '#0ff5ff',
                  width: 1.5
                },
                areaStyle: {
                  color: 'rgba(14, 245, 255, 0.3)',
                },
                itemStyle: {
                  color: '#0ff5ff',
                  lineStyle: {
                    color: '#0ff5ff',
                  }
                },
              },
            ]
          },
        ]
      };
      this.chart.setOption(option)
      window.addEventListener('resize', () => {
        if (this.chart) {
          this.chart.resize()
        }
      })
    },
  }
}
</script>

<style lang="scss" scoped>
.chart-wrapper {
  width: 100%;
  height: 100%;
}
.chart {
  width: 100%;
  height: 100%;
}
</style>
