圆柱体柱状图
<template>
  <div class="cylinder-wrapper">
    <div ref="chart" class="chart"></div>
  </div>
</template>

<script>

export default {
  name: 'Cylinder',
  props: {
    data: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      max: [],
      min: [],
      nameList: [],
      timer: null
    }
  },
  watch: {
    data() {
      this.refreshData()
    }
  },
  mounted() {
    this.refreshData()
  },
  beforeDestroy() {
    this.clearTimer()
  },
  methods: {
    refreshData() {
      this.clearTimer()
      this.getMaxData()
      this.initChart()
      this.timer = setInterval(() => {
        if (this.chart) {
          this.chart.dispose()
        }
        this.initChart()
      }, 5000);
    },
    clearTimer() {
      if (this.timer) {
        clearInterval(this.timer)
        this.timer = null
      }
    },
    getMaxData() {
      this.max = []
      this.min = []
      this.nameList = []
      const maxValue = Math.max(...this.data.map((item) => item.value)) / 0.9
      this.data.forEach((item) => {
        this.nameList.push(item.name)
        this.max.push(maxValue)
        this.min.push(0.1)
      })
    },
    initChart() {
      this.chart = this.$echarts.init(this.$refs.chart)
      const option = {
        textStyle: {
          color: '#ffffff',
          fontSize: 12
        },
        toolbox: {
          show: false,
        },
        legend: {
          show: false
        },
        tooltip: {
          show: false
        },
        color: ['#63caff'],
        grid: {
          show: false,
          containLabel: true,
          left: 0,
          right: 0,
          bottom: 30,
          top: 30
        },
        xAxis: {
          nameTextStyle: {
            color: '#7bb0c5',
            padding: [0, 0, -10, 0],
            fontSize: 12
          },
          axisLabel: {
            type: 'category',
            color: '#7bb0c5',
            fontSize: 12,
            interval: 0
          },
          axisTick: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLine: {
            show: false
          },
          data: this.nameList
        },
        yAxis: {
          show: false,
          max: this.max[0],
          axisLabel: {
            show: false,
            type: 'category',
            color: '#7bb0c5',
            fontSize: 12,
            interval: 0
          },
        },
        series: [{
          // 值的圆柱
          data: this.data,
          type: 'bar',
          barMaxWidth: 'auto',
          barWidth: 35,
          itemStyle: {
            color: {
              x: 0,
              y: 0,
              x2: 1,
              y2: 0,
              type: 'linear',
              global: false,
              colorStops: [{
                offset: 0,
                color: '#34add3'
              }, {
                offset: 1,
                color: '#117d9e'
              }]
            }
          },
          label: {
            show: true,
            position: 'top',
            distance: 10,
            color: '#fff'
          }
        }, { // 最下层圆
          data: this.min,
          type: 'pictorialBar',
          barMaxWidth: '35',
          symbolOffset: [0, '50%'],
          symbolSize: [35, 10],
          itemStyle: {
            color: {
              x: 0,
              y: 0,
              x2: 1,
              y2: 0,
              type: 'linear',
              global: false,
              colorStops: [{
                offset: 0,
                color: '#34add3'
              }, {
                offset: 1,
                color: '#117d9e'
              }]
            }
          }
        }, { // 值的圆
          data: this.data,
          type: 'pictorialBar',
          barMaxWidth: '35',
          symbolPosition: 'end',
          symbolOffset: [0, '-50%'],
          symbolSize: [35, 10],
          zlevel: 2,
          itemStyle: {
            color: {
              x: 0,
              y: 0,
              x2: 1,
              y2: 0,
              type: 'linear',
              global: false,
              colorStops: [{
                offset: 0,
                color: '#addbee'
              }, {
                offset: 1,
                color: '#2fa2c9'
              }]
            }
          },
        }, { // 底层圆柱
          data: this.max,
          type: 'bar',
          barMaxWidth: 'auto',
          barWidth: 35,
          barGap: '-100%',
          zlevel: -1,
          itemStyle: {
            color: {
              x: 0,
              y: 0,
              x2: 1,
              y2: 0,
              type: 'linear',
              global: false,
              colorStops: [{
                offset: 0,
                color: 'rgba(170, 183, 198, 0.3)'
              }, {
                offset: 1,
                color: 'rgba(255, 255, 255, 0.3)'
              }]
            }
          }
        }, { // 最上层圆
          data: this.max,
          type: 'pictorialBar',
          barMaxWidth: '35',
          symbolPosition: 'end',
          symbolOffset: [0, '-50%'],
          symbolSize: [35, 10],
          zlevel: 2,
          itemStyle: {
            color: {
              x: 0,
              y: 0,
              x2: 1,
              y2: 0,
              type: 'linear',
              global: false,
              colorStops: [{
                offset: 0,
                color: '#596778'
              }, {
                offset: 1,
                color: '#85909d'
              }]
            }
          }
        }]
      }
      this.chart.setOption(option)
      window.addEventListener('resize', () => {
        if (this.chart) {
          this.chart.resize()
        }
      })
    },
  }
}
</script>

<style lang="scss" scoped>
.cylinder-wrapper {
  width: 100%;
  height: 100%;
}
.chart {
  width: 100%;
  height: 100%;
}
</style>
