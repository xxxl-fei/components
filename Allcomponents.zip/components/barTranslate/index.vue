<template>
  <div class="bar-translate">
    <div :class="['main-trans', timerCount ? 'trans-trans' : '']">
      <div
        :class="['trans-div']"
        ref="transDiv"
        v-for="(item, index) in showData"
        :key="index"
      >
        <div class="count-detail">
          <div
            class="country-name"
            :style="{
              '--margin-left': `${-(item.name.length * 14 - 90)}px`,
            }"
          >
            <span
              :class="{
                animate: item.name.length > 6,
              }"
            >
              {{ item.name }}
            </span>
          </div>
          <div class="count-backg">
            <div
              class="bar-backg"
              :style="{
                width: item.value
                  ? parseInt(
                      ((item.value * 10000) / Math.ceil(max * 10000)) * 100
                    ) + '%'
                  : 0,
              }"
            >
              <div class="count-bar"></div>
            </div>
          </div>
          <div class="country-count">{{ item.value }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'BarTranslate',
  props: {
    data: {
      type: Array,
      default: () => []
    },
    rows: {
      type: Number,
      default: 4
    }
  },
  data() {
    return {
      max: 0,
      showData: [],
      timer: '',
      timerCount: false,
      timersss: '',
      startIndex: 0
    }
  },
  computed: {},
  created() {},
  mounted() {
    this.getMaxData()
    this.getRangeData()
  },
  beforeDestroy() {
    this.clearTimer()
  },
  methods: {
    getMaxData() {
      const arr = []
      this.max = 0
      this.data.forEach((item) => {
        // this.timerssss = setTimeout(() => {
        //   const width = `${parseInt(((item.value * 10000) / Math.ceil(this.max * 10000)) * 100, 10)}%`
        //   item.rotateHAHA = `0%{width: 0%;}100%{width: ${width};}`
        // }, 100)
        arr.push(item.value)
      })
      this.max = Math.max(...arr) / 0.99
    },
    getShowData() {
      const showData = this.data.slice(this.startIndex, this.startIndex + this.rows)
      this.showData = showData
    },
    getRangeData() {
      this.getShowData()
      this.timerCount = false
      this.clearTimer()
      this.timer = setInterval(() => {
        this.timerCount = false
        this.timersss = setTimeout(() => {
          this.startIndex += this.rows
          if (this.startIndex >= this.data.length) {
            this.startIndex = 0
          }
          this.getShowData()
          this.timerCount = true
        }, 500)
      }, 5000)
    },
    clearTimer() {
      if (this.timer) {
        clearInterval(this.timer)
        this.timer = null
      }
    }
  },
}
</script>
<style lang="scss" scoped>
.bar-translate {
  margin-left: auto;
  margin-right: auto;
  position: relative;
  overflow: hidden;
  list-style: none;
  padding: 0;
  z-index: 1;
  .main-trans {
    height: 100%;
    width: 100%;
    .trans-div {
      width: 100%;
      margin-bottom: 10px;
      &:last-child {
        margin-bottom: 0;
      }

      .count-detail {
        display: flex;
        width: 100%;
        .country-name {
          width: 90px;
          font-size: 14px;
          text-align: right;
          white-space: nowrap;
          overflow: hidden;
          .animate {
            display: inline-block;
            white-space: nowrap;
            animation: wordsLoop 5s linear infinite;
          }
        }
        .count-backg {
          background: rgba(27, 62, 95, 0.7);
          width: calc(100% - 90px - 60px - 10px); // 53%;
          margin: 3px 0 0 10px;
          height: 5px;
          .bar-backg {
            height: 100%;
            .count-bar {
              width: 100%;
              height: 100%;
              background-color: #01b4e9;
            }
          }
        }
        .country-count {
          width: 60px;
          margin-left: 10px;
          font-size: 14px;
          line-height: 10px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          // transition: transform 2s cubic-bezier(0.15, 0.52, 0.5, 0.9) 0s;
          // -webkit-transition: all 0.5s ease-in;
          // -moz-transition: all 0.5s ease-in;
          transition: all 0.5s ease-in;
        }
      }
    }
    &.trans-trans {
      .count-bar {
        width: 100%;
        animation: rotateHAHA 2s linear;
      }
    }
  }
}
@keyframes rotateHAHA {
  0% {
    width: 0%;
  }
  100% {
    width: 100%;
  }
}
@keyframes wordsLoop {
  0% {
    transform: translateX(14px);
  }
  50% {
    transform: translateX(var(--margin-left));
  }
  100% {
    transform: translateX(14px);
  }
}
</style>
