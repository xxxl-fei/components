词云
使用方法参考：https://github.com/ecomfe/echarts-wordcloud
<template>
  <div class="word-cloud">
    <div id="tagsList">
      <span
        @mouseenter="clearTimer"
        @mouseleave="leaveFunc"
        v-for="(talent, index) in data"
        :key="index"
      >
        <a>{{ talent.title }}</a>
      </span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'WordCloud',
  props: {
    data: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      chart: null,
      aniInterval: null,
      radius: 80,
      dtr: Math.PI / 180,
      d: 300,
      mcList: [],
      distr: true,
      tspeed: 1,
      size: 250,
      howElliptical: 1,
      aA: null,
      oDiv: null,
    }
  },
  mounted() {
    this.initRoll()
  },
  destroyed() {
    this.clearTimer()
  },
  methods: {
    initRoll() {
      let i = 0;
      let oTag = null;

      this.oDiv = document.getElementById('tagsList');
      this.aA = this.oDiv.getElementsByTagName('a');

      for (i = 0; i < this.aA.length; i += 1) {
        oTag = {};
        oTag.offsetWidth = this.aA[i].offsetWidth;
        oTag.offsetHeight = this.aA[i].offsetHeight;
        this.mcList.push(oTag);
      }
      this.sineCosine(0, 0, 0);
      this.positionAll();
      this.clearTimer();
      this.aniInterval = setInterval(this.update, 20);
    },
    update() {
      const a = (-Math.min(Math.max(-0.1 * this.size, -this.size), this.size) / this.radius) * this.tspeed;
      const b = (Math.min(Math.max(-0.1 * this.size, -this.size), this.size) / this.radius) * this.tspeed;

      if (Math.abs(a) <= 0.01 && Math.abs(b) <= 0.01) return;
      const {
        sa, ca, sb, cb, sc, cc
      } = this.sineCosine(a, b, 0);
      for (let j = 0; j < this.mcList.length; j += 1) {
        const rx1 = this.mcList[j].cx;
        const ry1 = this.mcList[j].cy * ca + this.mcList[j].cz * (-sa);
        const rz1 = this.mcList[j].cy * sa + this.mcList[j].cz * ca;

        const rx2 = rx1 * cb + rz1 * sb;
        const ry2 = ry1;
        const rz2 = rx1 * (-sb) + rz1 * cb;

        const rx3 = rx2 * cc + ry2 * (-sc);
        const ry3 = rx2 * sc + ry2 * cc;

        this.mcList[j].cx = rx3;
        this.mcList[j].cy = ry3;
        this.mcList[j].cz = rz2;

        const per = this.d / (this.d + rz2);

        this.mcList[j].x = (this.howElliptical * rx3 * per) - (this.howElliptical * 2);
        this.mcList[j].y = ry3 * per;
        this.mcList[j].scaleX = per;
        this.mcList[j].scaleY = per;
        this.mcList[j].alpha = per;

        this.mcList[j].alpha = (per - 0.9) * (10 / 3);
      }

      this.doPosition();
      this.depthSort();
    },
    depthSort() {
      const aTmp = [];

      for (let i = 0; i < this.aA.length; i += 1) {
        aTmp.push(this.aA[i]);
      }

      aTmp.sort((vItem1, vItem2) => {
        if (vItem1.cz > vItem2.cz) {
          return -1;
        } if (vItem1.cz < vItem2.cz) {
          return 1;
        }
        return 0;
      });

      for (let i = 0; i < aTmp.length; i += 1) {
        aTmp[i].style.zIndex = i;
      }
    },
    positionAll() {
      let phi = 0;
      let theta = 0;
      const max = this.mcList.length;

      for (let i = 1; i < max + 1; i += 1) {
        if (this.distr) {
          phi = Math.acos(-1 + (2 * i - 1) / max);
          theta = Math.sqrt(max * Math.PI) * phi;
        } else {
          phi = Math.random() * (Math.PI);
          theta = Math.random() * (2 * Math.PI);
        }
        // 坐标变换
        this.mcList[i - 1].cx = this.radius * Math.cos(theta) * Math.sin(phi);
        this.mcList[i - 1].cy = this.radius * Math.sin(theta) * Math.sin(phi);
        this.mcList[i - 1].cz = this.radius * Math.cos(phi);

        this.aA[i - 1].style.left = `${this.mcList[i - 1].cx + this.oDiv.offsetWidth / 2 - this.mcList[i - 1].offsetWidth / 2}px`;
        this.aA[i - 1].style.top = `${this.mcList[i - 1].cy + this.oDiv.offsetHeight / 2 - this.mcList[i - 1].offsetHeight / 2}px`;
      }
    },
    doPosition() {
      const l = this.oDiv.offsetWidth / 2;
      const t = this.oDiv.offsetHeight / 2;
      for (let i = 0; i < this.mcList.length; i += 1) {
        this.aA[i].style.left = `${this.mcList[i].cx + l - this.mcList[i].offsetWidth / 2}px`;
        this.aA[i].style.top = `${this.mcList[i].cy + t - this.mcList[i].offsetHeight / 2}px`;
        this.aA[i].style.filter = `alpha(opacity=${100 * this.mcList[i].alpha})`;
        this.aA[i].style.opacity = this.mcList[i].alpha;
      }
    },
    sineCosine(a, b, c) {
      return {
        sa: Math.sin(a * this.dtr),
        ca: Math.cos(a * this.dtr),
        sb: Math.sin(b * this.dtr),
        cb: Math.cos(b * this.dtr),
        sc: Math.sin(c * this.dtr),
        cc: Math.cos(c * this.dtr),
      }
    },
    // 清除定时器
    clearTimer() {
      if (this.aniInterval) {
        clearInterval(this.aniInterval)
      }
      this.aniInterval = null
    },
    leaveFunc() {
      this.clearTimer()
      this.aniInterval = setInterval(this.update, 10);
    }
  }
}
</script>

<style lang="scss" scoped>
.word-cloud {
  overflow: hidden;
  #tagsList {
    position: relative;
    width: 100%;
    height: 155px;
    margin: 10px auto 0;
  }
  #tagsList a {
    position: absolute;
    top: 0px;
    left: 0px;
    font-family: Microsoft YaHei;
    color: #2abaab;
    text-decoration: none;
    padding: 3px 6px;
    cursor: pointer;
  }
}
</style>
