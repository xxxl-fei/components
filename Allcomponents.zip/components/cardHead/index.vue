<template>
  <div class="card-head">
    <span class="">{{ title }}</span>
    <div class="tool">
      <div class="tool-ctl view-code">
        <i class="el-icon-view" @click="previewCode"></i>
        <!-- <span>预览代码</span> -->
      </div>
      <div class="tool-ctl view-code">
        <i class="el-icon-download" @click="downloadCode"></i>
        <!-- <span>下载代码</span> -->
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Navbar',
  props: {
    title: {
      type: String,
      default: ''
    }
  },
  data() {
    return {}
  },
  methods: {
    previewCode() {
      this.$emit('previewCode')
    },
    downloadCode() {
      this.$emit('downloadCode')
    }
  }
}
</script>
<style lang="scss" scoped>
.card-head {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 0 5px 0;
  .tool {
    display: flex;
    .tool-ctl {
      margin-right: 10px;
      cursor: pointer;
    }
  }
}
</style>
