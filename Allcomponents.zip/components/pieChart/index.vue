<template>
  <div class="box">
    <div class="chart" ref="chart"></div>
    <div class="count-box" :style="{'color': colors[count]}">
      <countTo
        :startVal='startVal'
        :endVal='endVal'
        :duration='2000'
        class="num"></countTo>
      <transition name="component-fade" mode="out-in">
        <p class="name" v-show="flag">{{countName}}</p>
      </transition>
    </div>
  </div>
</template>
<script>
import CountTo from 'vue-count-to'

export default {
  name: 'PieChart',
  props: {
    data: {
      type: Array,
      default: () => []
    }
  },
  components: {
    CountTo,
  },
  data() {
    return {
      chart: null,
      interval: null,
      startVal: 0,
      endVal: 0,
      countName: '',
      flag: true,
      count: null,
      colors: [
        '#EEEC0D',
        '#E55125',
        '#5EA6FE',
        '#F94ED2',
        '#67D670',
        '#67FFFC',
      ]
    }
  },
  watch: {
    count(v) {
      // 取消高亮指定的数据图形
      this.chart.dispatchAction({
        type: 'downplay',
        seriesIndex: 0,
        dataIndex: v === 0 ? this.data.length - 1 : v - 1
      });
      // 高亮指定的数据图形
      this.chart.dispatchAction({
        type: 'highlight',
        seriesIndex: 0,
        dataIndex: v
      });
    }
  },
  mounted() {
    this.initChart()
  },
  beforeDestroy() {
    this.clearTimer()
  },
  methods: {
    startSelectAnimate() {
      this.count = 0
      this.startVal = this.endVal
      this.endVal = this.data[this.count].value
      this.countName = this.data[this.count].name
      this.clearTimer()
      this.interval = setInterval(() => {
        if (this.count < this.data.length - 1) {
          this.count += 1
        } else {
          this.count = 0
        }
        this.startVal = this.endVal
        this.endVal = this.data[this.count].value
        this.countName = this.data[this.count].name
      }, 3000)
    },
    clearTimer() {
      clearInterval(this.interval)
      this.interval = null
    },
    initChart() {
      const option = {
        color: this.colors,
        legend: {
          show: true,
          left: 10,
          top: 20,
          bottom: 20,
          icon: 'circle',
          orient: 'vertical',
          textStyle: {
            color: '#fff',
            fontSize: 14,
            fontWeight: 400
          },
          data: this.data.map((i) => i.name)
        },
        series: [
          {
            type: 'pie',
            z: 10,
            startAngle: 160,
            radius: ['27%', '45%'],
            center: ['50%', '55%'],
            roseType: 'radius',
            label: {
              show: false,
              position: 'center',
              color: '#EBE806',
              formatter: (params) => {
                const str = `{top|${params.data.value}}\n{bottom|${params.data.name}}`
                return str
              },
              rich: {
                top: {
                  color: '#EBE806',
                  fontSize: 18,
                  fontWeight: 400,
                },
                bottom: {
                  color: '#EBE806',
                  fontSize: 18,
                  fontWeight: 400,
                  padding: [0, 0, 10, 0],
                },
              },
            },
            emphasis: {
              label: {
                show: false,
              },
              itemStyle: {},
            },
            data: this.data
          },
        ],
      };
      this.chart = this.$echarts.init(this.$refs.chart)
      this.chart.setOption(option);
      this.startSelectAnimate();
      window.addEventListener('resize', () => {
        this.chart.resize()
      })
    },
  },
};
</script>
<style lang="scss" scoped>
.box {
  height: 100%;
  width: 100%;
  position: relative;
}
.chart {
  width: 100%;
  height: 100%;
}
.count-box {
    position: absolute;
    top: 55%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 80px;
    text-align: center;
    color: #fff;
    .num {
      font-size: 14px;
      font-weight: bold;
    }
    .name {
      font-size: 12px;
      margin-top: 5px
    }
  }
  .component-fade-enter-active, .component-fade-leave-active {
    transition: opacity .3s ease;
  }
  .component-fade-enter, .component-fade-leave-to
  /* .component-fade-leave-active for below version 2.1.8 */ {
    opacity: 0;
  }
</style>
