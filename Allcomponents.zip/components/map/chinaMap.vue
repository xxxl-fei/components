省外来源地
<template>
  <div class="map-chart" ref="chinaMap"></div>
</template>
<script>
import { toThousands } from '@/utils'
import { GeoCoordMap } from '@/utils/geoCoordMap' // 坐标字典

export default {
  name: 'ProvinceOut',
  props: {
    kpiArea: {
      type: Number,
      default: null
    },
    destName: {
      type: String,
      default: '西湖'
    },
    data: {
      type: Array,
      default: () => []
    }
  },
  components: {},
  data() {
    return {}
  },
  watch: {
    data() {
      this.initChinaMap()
    },
  },
  mounted() {
    this.initChinaMap()
  },
  methods: {
    async initChinaMap() {
      const chinaJson = await require('../../../../dataSource/qg.json')
      const idata = this.data
      this.$echarts.registerMap('china', chinaJson);
      const chinaDatas = idata.filter((item) => item.name !== '浙江')
      const series = [
        {
          type: 'lines',
          zlevel: 1,
          animation: false,
          effect: {
            show: true,
            period: 4, // 箭头指向速度，值越小速度越快
            trailLength: 0.02, // 特效尾迹长度[0,1]值越大，尾迹越长重
            symbol: 'arrow', // 箭头图标
            symbolSize: 5, // 图标大小
          },
          lineStyle: {
            width: 1, // 尾迹线条宽度
            opacity: 1, // 尾迹线条透明度
            curveness: 0.3 // 尾迹线条曲直度
          },
          data: this.convertData(chinaDatas)
        },
        {
          type: 'effectScatter',
          coordinateSystem: 'geo',
          zlevel: 2,
          showEffectOn: 'render',
          rippleEffect: { // 涟漪特效
            period: 4, // 动画时间，值越小速度越快
            brushType: 'stroke', // 波纹绘制方式 stroke, fill
            scale: 4.5 // 波纹圆环最大限制，值越大波纹越大
          },
          label: {
            show: true,
            color: '#fff',
            position: 'right', // 显示位置
            offset: [3, 0], // 偏移设置
            formatter: (params) => params.data.name, // 圆环显示文字
            fontSize: 13
          },
          symbolSize: 5, // (val) => Math.min(val[2] / 100, 20), // 圆环大小
          itemStyle: {
            show: false
          },
          data: chinaDatas.map((dataItem) => ({
            name: dataItem.name,
            value: GeoCoordMap[dataItem.name].concat([dataItem.value])
          })),
        },
        {
          type: 'scatter',
          coordinateSystem: 'geo',
          zlevel: 2,
          symbol: 'pin',
          symbolSize: 35,
          label: {
            show: true,
            position: 'bottom',
            offset: [5, 0],
            color: '#fff',
            formatter: '{b}',
          },
          textStyle: {
            color: '#fff'
          },
          emphasis: {
            label: {
              show: true,
              color: '#fff'
            }
          },
          itemStyle: {
            color: '#ff3333'
          },
          data: [{
            name: this.destName,
            visualMap: false,
            value: GeoCoordMap[this.destName],
          }],
        }
      ]
      const option = {
        tooltip: {
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          textStyle: {
            color: '#fff',
          },
          formatter: (params) => {
            if (params.componentSubType === 'lines') {
              return `${params.data.fromName}->${params.data.toName}: ${toThousands(params.data.value)}人`
            }
            return ''
          }
        },
        visualMap: [{ // 图例值控制
          type: 'piecewise',
          calculable: true,
          show: false,
          left: 0,
          color: ['#ff3333', '#ffa500', '#ffff00', '#0aff00', '#00ffff'],
          pieces: [
            // { min: 1500 }, // 不指定 max，表示 max 为无限大（Infinity）。
            { min: 800 },
            { min: 600, max: 800 },
            { min: 400, max: 600 },
            { min: 200, max: 400 },
            { min: 0, max: 200 },
          ],
          itemSymbol: 'rect', // 单独设置itemSymbol不起作用，需要设置inRange
          controller: {
            inRange: {
              color: ['#00ffff', '#0aff00', '#ffff00', '#ffa500', '#ff3333'],
              symbol: 'rect'
            }
          },
          textStyle: {
            color: '#fff'
          },
          formatter: (value, value2) => `${toThousands(value)} - ${toThousands(value2)}` // 范围标签显示内容。
        }],
        geo: {
          map: 'china',
          zoom: 1.3,
          center: [104.30, 34.71],
          roam: false, // 是否允许缩放
          itemStyle: {
            color: 'rgba(2, 87, 136, .8)', // 地图背景色
            borderColor: '#2ad1e7', // 省市边界线00fcff 516a89
            borderWidth: 1
          },
          emphasis: {
            label: {
              show: false
            },
            itemStyle: {
              color: 'rgba(37, 43, 61, .5)' // 悬浮背景
            }
          }
        },
        series
      };

      this.chart = this.$echarts.init(this.$refs.chinaMap);
      this.chart.setOption(option, true);
      window.addEventListener('resize', () => {
        if (this.chart) {
          this.chart.resize()
        }
      })
    },
    convertData(data) {
      const res = [];
      for (let i = 0; i < data.length; i += 1) {
        const dataItem = data[i];
        const fromCoord = GeoCoordMap[dataItem.name]; // 来源地
        const toCoord = GeoCoordMap[this.destName]; // 目的地
        if (fromCoord && toCoord) {
          res.push({
            fromName: dataItem.name,
            toName: this.destName,
            value: dataItem.value,
            coords: [fromCoord, toCoord]
          })
        }
      }
      return res
    }
  }
}
</script>
<style lang="scss" scoped>
.map-chart {
  width: 100%;
  height: 100%;
}
</style>
