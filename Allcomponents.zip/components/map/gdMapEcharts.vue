Apache ECharts 高德地图扩展
实例及说明参考：https://github.com/plainheart/echarts-extension-amap/blob/master/README.zh-CN.md

<template>
  <div class="map-container">
    <div class="map" ref="gdMapChart"></div>
  </div>
</template>
<script>
import * as echarts from 'echarts';
import 'echarts-extension-amap';
// import AMap from 'AMap';
import { GeoCoordMap } from '@/utils/geoCoordMap';

/**
 * lines数据
 * {
      fromName: '内蒙古', // 为了显示需要而增加的字段，还可以加其他任意字段
      toName: '广东', // 为了显示需要而增加的字段
      value: 1000, // 为了显示需要而增加的字段
      name: 'aa', // name
      coords: [[111.4124, 40.4901], [113.5107, 23.2196]], // 一个包含两个到多个二维坐标的数组 lines的两个端点坐标
    }
 */
export default {
  name: 'GdMap',
  data() {
    return {
      chart: null,
      map: null,
      data: [
        { name: '海门', value: 9 },
        { name: '鄂尔多斯', value: 12 },
        { name: '招远', value: 12 },
        { name: '舟山', value: 12 },
        { name: '齐齐哈尔', value: 14 },
        { name: '盐城', value: 15 },
        { name: '赤峰', value: 16 },
        { name: '青岛', value: 18 },
        { name: '乳山', value: 18 },
        { name: '金昌', value: 19 },
        { name: '泉州', value: 21 },
        { name: '莱西', value: 21 },
        { name: '日照', value: 21 },
        { name: '胶南', value: 22 },
        { name: '南通', value: 23 },
        { name: '拉萨', value: 24 },
        { name: '云浮', value: 24 },
        { name: '梅州', value: 25 },
        { name: '文登', value: 25 },
        { name: '上海', value: 25 },
        { name: '攀枝花', value: 25 },
        { name: '威海', value: 25 },
        { name: '承德', value: 25 },
        { name: '厦门', value: 26 },
        { name: '汕尾', value: 26 },
        { name: '潮州', value: 26 },
        { name: '丹东', value: 27 },
        { name: '太仓', value: 27 },
        { name: '曲靖', value: 27 },
        { name: '烟台', value: 28 },
        { name: '福州', value: 29 },
        { name: '瓦房店', value: 30 },
        { name: '即墨', value: 30 },
        { name: '抚顺', value: 31 },
        { name: '玉溪', value: 31 },
        { name: '张家口', value: 31 },
        { name: '阳泉', value: 31 },
        { name: '莱州', value: 32 },
        { name: '湖州', value: 32 },
        { name: '汕头', value: 32 },
        { name: '昆山', value: 33 },
        { name: '宁波', value: 33 },
        { name: '湛江', value: 33 },
        { name: '揭阳', value: 34 },
        { name: '荣成', value: 34 },
        { name: '连云港', value: 35 },
        { name: '葫芦岛', value: 35 },
        { name: '常熟', value: 36 },
        { name: '东莞', value: 36 },
        { name: '河源', value: 36 },
        { name: '淮安', value: 36 },
        { name: '泰州', value: 36 },
        { name: '南宁', value: 37 },
        { name: '营口', value: 37 },
        { name: '惠州', value: 37 },
        { name: '江阴', value: 37 },
        { name: '蓬莱', value: 37 },
        { name: '韶关', value: 38 },
        { name: '嘉峪关', value: 38 },
        { name: '广州', value: 38 },
        { name: '延安', value: 38 },
        { name: '太原', value: 39 },
        { name: '清远', value: 39 },
        { name: '中山', value: 39 },
        { name: '昆明', value: 39 },
        { name: '寿光', value: 40 },
        { name: '盘锦', value: 40 },
        { name: '长治', value: 41 },
        { name: '深圳', value: 41 },
        { name: '珠海', value: 42 },
        { name: '宿迁', value: 43 },
        { name: '咸阳', value: 43 },
        { name: '铜川', value: 44 },
        { name: '平度', value: 44 },
        { name: '佛山', value: 44 },
        { name: '海口', value: 44 },
        { name: '江门', value: 45 },
        { name: '章丘', value: 45 },
        { name: '肇庆', value: 46 },
        { name: '大连', value: 47 },
        { name: '临汾', value: 47 },
        { name: '吴江', value: 47 },
        { name: '石嘴山', value: 49 },
        { name: '沈阳', value: 50 },
        { name: '苏州', value: 50 },
        { name: '茂名', value: 50 },
        { name: '嘉兴', value: 51 },
        { name: '长春', value: 51 },
        { name: '胶州', value: 52 },
        { name: '银川', value: 52 },
        { name: '张家港', value: 52 },
        { name: '三门峡', value: 53 },
        { name: '锦州', value: 54 },
        { name: '南昌', value: 54 },
        { name: '柳州', value: 54 },
        { name: '三亚', value: 54 },
        { name: '自贡', value: 56 },
        { name: '吉林', value: 56 },
        { name: '阳江', value: 57 },
        { name: '泸州', value: 57 },
        { name: '西宁', value: 57 },
        { name: '宜宾', value: 58 },
        { name: '呼和浩特', value: 58 },
        { name: '成都', value: 58 },
        { name: '大同', value: 58 },
        { name: '镇江', value: 59 },
        { name: '桂林', value: 59 },
        { name: '张家界', value: 59 },
        { name: '宜兴', value: 59 },
        { name: '北海', value: 60 },
        { name: '西安', value: 61 },
        { name: '金坛', value: 62 },
        { name: '东营', value: 62 },
        { name: '牡丹江', value: 63 },
        { name: '遵义', value: 63 },
        { name: '绍兴', value: 63 },
        { name: '扬州', value: 64 },
        { name: '常州', value: 64 },
        { name: '潍坊', value: 65 },
        { name: '重庆', value: 66 },
        { name: '台州', value: 67 },
        { name: '南京', value: 67 },
        { name: '滨州', value: 70 },
        { name: '贵阳', value: 71 },
        { name: '无锡', value: 71 },
        { name: '本溪', value: 71 },
        { name: '克拉玛依', value: 72 },
        { name: '渭南', value: 72 },
        { name: '马鞍山', value: 72 },
        { name: '宝鸡', value: 72 },
        { name: '焦作', value: 75 },
        { name: '句容', value: 75 },
        { name: '北京', value: 79 },
        { name: '徐州', value: 79 },
        { name: '衡水', value: 80 },
        { name: '包头', value: 80 },
        { name: '绵阳', value: 80 },
        { name: '乌鲁木齐', value: 84 },
        { name: '枣庄', value: 84 },
        { name: '杭州', value: 84 },
        { name: '淄博', value: 85 },
        { name: '鞍山', value: 86 },
        { name: '溧阳', value: 86 },
        { name: '库尔勒', value: 86 },
        { name: '安阳', value: 90 },
        { name: '开封', value: 90 },
        { name: '济南', value: 92 },
        { name: '德阳', value: 93 },
        { name: '温州', value: 95 },
        { name: '九江', value: 96 },
        { name: '邯郸', value: 98 },
        { name: '临安', value: 99 },
        { name: '兰州', value: 99 },
        { name: '沧州', value: 100 },
        { name: '临沂', value: 103 },
        { name: '南充', value: 104 },
        { name: '天津', value: 105 },
        { name: '富阳', value: 106 },
        { name: '泰安', value: 112 },
        { name: '诸暨', value: 112 },
        { name: '郑州', value: 113 },
        { name: '哈尔滨', value: 114 },
        { name: '聊城', value: 116 },
        { name: '芜湖', value: 117 },
        { name: '唐山', value: 119 },
        { name: '平顶山', value: 119 },
        { name: '邢台', value: 119 },
        { name: '德州', value: 120 },
        { name: '济宁', value: 120 },
        { name: '荆州', value: 127 },
        { name: '宜昌', value: 130 },
        { name: '义乌', value: 132 },
        { name: '丽水', value: 133 },
        { name: '洛阳', value: 134 },
        { name: '秦皇岛', value: 136 },
        { name: '株洲', value: 143 },
        { name: '石家庄', value: 147 },
        { name: '莱芜', value: 148 },
        { name: '常德', value: 152 },
        { name: '保定', value: 153 },
        { name: '湘潭', value: 154 },
        { name: '金华', value: 157 },
        { name: '岳阳', value: 169 },
        { name: '长沙', value: 175 },
        { name: '衢州', value: 177 },
        { name: '廊坊', value: 193 },
        { name: '菏泽', value: 194 },
        { name: '合肥', value: 229 },
        { name: '武汉', value: 273 },
        { name: '大庆', value: 279 },
      ],
    };
  },
  mounted() {
    this.initChart();
  },
  methods: {
    initChart() {
      const planePath = 'path://M275.2 864c0 0 128-102.4 236.8-108.8 108.8 6.4 236.8 108.8 236.8 108.8-6.4-108.8-83.2-179.2-83.2-179.2C761.6 320 505.6 0 505.6 0S256 320 358.4 684.8C358.4 684.8 275.2 761.6 275.2 864zM473.6 192l64 0c0 0 83.2 0 83.2 192L396.8 384C390.4 192 473.6 192 473.6 192zM576 793.6l-70.4-12.8-70.4 12.8c0 0-44.8 19.2-38.4 44.8 6.4 25.6 57.6 153.6 102.4 179.2 44.8-19.2 96-147.2 102.4-179.2C620.8 812.8 576 793.6 576 793.6z'
      const startPath = 'path://M997.292771 456.485456L578.299624 28.020935a92.563491 92.563491 0 0 0-132.548052 0L26.707229 456.485456c-56.981839 58.312951-16.587705 157.992772 63.995777 157.992772H153.623653V921.606758a102.393242 102.393242 0 0 0 102.393242 102.393242h153.589863v-255.931908A51.196621 51.196621 0 0 1 460.803379 716.820274h102.444439a51.196621 51.196621 0 0 1 51.196621 51.247818V1024H767.983105a102.444439 102.444439 0 0 0 102.495635-102.393242v-307.12853h62.818254c80.583481 0 120.977615-99.731018 63.995777-157.992772z m0 0'
      const endPath = 'path://M667.786667 117.333333C832.864 117.333333 938.666667 249.706667 938.666667 427.861333c0 138.250667-125.098667 290.506667-371.573334 461.589334a96.768 96.768 0 0 1-110.186666 0C210.432 718.368 85.333333 566.112 85.333333 427.861333 85.333333 249.706667 191.136 117.333333 356.213333 117.333333c59.616 0 100.053333 20.832 155.786667 68.096C567.744 138.176 608.170667 117.333333 667.786667 117.333333z m0 63.146667c-41.44 0-70.261333 15.189333-116.96 55.04-2.165333 1.845333-14.4 12.373333-17.941334 15.381333a32.32 32.32 0 0 1-41.770666 0c-3.541333-3.018667-15.776-13.536-17.941334-15.381333-46.698667-39.850667-75.52-55.04-116.96-55.04C230.186667 180.48 149.333333 281.258667 149.333333 426.698667 149.333333 537.6 262.858667 675.242667 493.632 834.826667a32.352 32.352 0 0 0 36.736 0C761.141333 675.253333 874.666667 537.6 874.666667 426.698667c0-145.44-80.853333-246.218667-206.88-246.218667z'
      const option = {
        // 加载 amap 组件
        amap: {
          // 3D模式，无论你使用的是1.x版本还是2.x版本，都建议开启此项以获得更好的渲染体验
          viewMode: '2D',
          // 高德地图支持的初始化地图配置
          // 高德地图初始中心经纬度
          center: [108.39, 39.9],
          // 高德地图初始缩放级别
          zoom: 4,
          features: ['bg', 'road'],
          // 是否开启resize
          resizeEnable: true,
          // 自定义地图样式主题
          mapStyle: 'amap://styles/4eb1677fab99b6dbab2ab9a86d41c4bf',
          // 移动过程中实时渲染 默认为true 如数据量较大 建议置为false
          renderOnMoving: true,
          // ECharts 图层的 zIndex 默认 2000
          // 从 v1.9.0 起 此配置项已被弃用 请使用 `echartsLayerInteractive` 代替
          // echartsLayerZIndex: 2019,
          // 设置 ECharts 图层是否可交互 默认为 true
          // 设置为 false 可实现高德地图自身图层交互
          // 此配置项从 v1.9.0 起开始支持
          echartsLayerInteractive: true,
          // 是否启用大数据模式 默认为 false
          // 此配置项从 v1.9.0 起开始支持
          largeMode: false,
          // 说明：如果想要添加卫星、路网等图层
          // 暂时先不要使用layers配置，因为存在Bug
          // 建议使用amap.add的方式，使用方式参见最下方代码
        },
        tooltip: {
          trigger: 'item',
        },
        animation: true,
        series: [
          {
            name: 'PM2.5',
            type: 'scatter',
            // 使用高德地图坐标系
            coordinateSystem: 'amap',
            // 数据格式跟在 geo 坐标系上一样，每一项都是 [经度，纬度，数值大小，其它维度...]
            data: this.convertData(this.data),
            symbolSize: (val) => val[2] / 10,
            encode: {
              value: 2,
            },
            label: {
              formatter: '{b}',
              position: 'right',
              show: false,
            },
            itemStyle: {
              color: '#00c1de',
            },
            emphasis: {
              label: {
                show: true,
                color: '#fff',
                fontSize: 14,
                textBorderColor: '#000',
                textBorderWidth: 1
              },
            },
          },
          {
            name: 'Top 5',
            type: 'effectScatter',
            coordinateSystem: 'amap',
            data: this.convertData(
              this.data
                .sort((a, b) => b.value - a.value)
                .slice(0, 6)
            ),
            symbolSize: (val) => val[2] / 10,
            encode: {
              value: 2,
            },
            showEffectOn: 'render',
            rippleEffect: {
              brushType: 'stroke',
            },
            label: {
              formatter: '{b}',
              position: 'right',
              show: true,
            },
            itemStyle: {
              color: '#fff',
              shadowBlur: 10,
              shadowColor: '#333',
            },
            zlevel: 1,
            emphasis: {}
          },
          {
            name: 'Lines',
            type: 'lines',
            coordinateSystem: 'amap',
            polyline: false, // 默认为false  只能用于绘制只有两个端点的线段，线段可以通过 lineStyle.curveness（曲率） 配置为曲线。如果该配置项为 true，则可以在 data.coords 中设置多于 2 个的顶点用来绘制多段线，在绘制路线轨迹的时候比较有用，比如：公交路线，设置为多段线后 lineStyle.curveness （曲率）无效。
            effect: {
              show: true,
              period: 4, // 特效动画时间，单位：s
              symbol: planePath, // 特效标记 可以设置图片
              symbolSize: 15, // 特效标记的大小
              trailLength: 0, // 特效尾迹的长度。取从 0 到 1 的值，数值越大尾迹越长。
              loop: true, // 是否循环显示特效。
            },
            symbol: [startPath, endPath],
            symbolSize: 20,
            lineStyle: {
              color: '#e6720c',
              width: 2, // 尾迹线条宽度
              opacity: 1, // 尾迹线条透明度
              curveness: 0.3 // 尾迹线条曲直度
            },
            zlevel: 3,
            // 数据集处理成这样的结果
            data: [{
              fromName: '内蒙古', // 为了显示需要而增加的字段，还可以加其他任意字段
              toName: '广东', // 为了显示需要而增加的字段
              value: 1000, // 为了显示需要而增加的字段
              name: 'aa', // name
              coords: [[111.4124, 40.4901], [113.5107, 23.2196]], // 一个包含两个到多个二维坐标的数组 lines的两个端点坐标
            }],
            tooltip: {
              formatter: (params) => {
                // console.log(params)
                const { data: { fromName, toName, value } } = params
                return `${fromName}-${toName}: ${value}`
              }
            }
          },
          {
            name: 'Lines',
            type: 'lines',
            coordinateSystem: 'amap',
            effect: {
              show: true,
              period: 4, // 特效动画时间，单位：s
              symbol: 'arrow', // 特效标记 可以设置图片
              symbolSize: '15', // 特效标记的大小
              trailLength: 0, // 特效尾迹的长度。取从 0 到 1 的值，数值越大尾迹越长。
              loop: true, // 是否循环显示特效。
            },
            lineStyle: {
              color: '#0ce679',
              width: 2, // 尾迹线条宽度
              opacity: 1, // 尾迹线条透明度
              curveness: 0.3, // 尾迹线条曲直度
              type: [10, 5],
              dashOffset: 20
            },
            zlevel: 4,
            // 数据集处理成这样的结果
            data: [{
              fromName: '广东',
              toName: '内蒙古',
              value: 2000,
              name: 'aa',
              coords: [[113.5107, 23.2196], [111.4124, 40.4901]], // 一个包含两个到多个二维坐标的数组
            }],
            tooltip: {
              formatter: (params) => {
                // console.log(params)
                const { data: { fromName, toName, value } } = params
                return `${fromName}-${toName}: ${value}`
              }
            }
          }
        ],
      };
      this.chart = echarts.init(this.$refs.gdMapChart);
      this.chart.setOption(option);
      // 获取 ECharts 高德地图组件
      const amapComponent = this.chart.getModel().getComponent('amap');
      // 获取高德地图实例，使用高德地图自带的控件(需要在高德地图js API script标签手动引入)
      const amap = amapComponent.getAMap();
      this.map = amap

      // // 添加控件
      // amap.addControl(new AMap.Scale());
      // amap.addControl(new AMap.ToolBar());

      // // 添加图层
      // const satelliteLayer = new AMap.TileLayer.Satellite();
      // const roadNetLayer = new AMap.TileLayer.RoadNet();
      // amap.add([satelliteLayer, roadNetLayer]);

      // //  添加一个 Marker
      // amap.add(
      //   new AMap.Marker({
      //     position: [115, 35],
      //   })
      // );

      // 禁用 ECharts 图层交互，从而使高德地图图层可以点击交互
      // amapComponent.setEChartsLayerInteractive(false);
    },
    convertData(data) {
      const res = [];
      for (let i = 0; i < data.length; i += 1) {
        const geoCoord = GeoCoordMap[data[i].name];
        if (geoCoord) {
          res.push({
            name: data[i].name,
            value: geoCoord.concat(data[i].value),
          });
        }
      }
      return res;
    }
  }
}
</script>
<style lang="scss">
.amap-logo {
  display: none !important;
}
.amap-copyright {
  display: none !important;
}
</style>
<style lang="scss" scoped>
.map-container {
  width: 100%;
  height: 100%;
  min-width: 200px;
  min-height: 400px;
  .map {
    width: 100%;
    height: 100%;
  }
}
</style>
