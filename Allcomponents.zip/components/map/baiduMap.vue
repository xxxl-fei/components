<template>
  <div class="map">
    <div
      id="container"
      style=""
      ref="map"
      v-loading="mapLoading"
      element-loading-spinner="el-icon-loading"
    ></div>
    <div class="mapType-wrapper">
      <div class="mapType">
        <div
          :class="['mapTypeCard normal', { active: activeType === 1 }]"
          @click="changeMapType(1)"
        >
          <span class="text">地图</span>
        </div>
        <div
          :class="['mapTypeCard earth', { active: activeType === 2 }]"
          @click="changeMapType(2)"
        >
          <span class="text">地球</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import BMap from 'BMap' // 引入百度地图

export default {
  data() {
    return {
      map: null,
      activeType: 1,
      
      mapLoading: false
    }
  },
  mounted() {
    this.initMap()
  },
  destroyed() {},
  methods: {
    changeMapType(type) {
      this.activeType = type
      if (type === 1) {
        this.map.setMapType(BMAP_NORMAL_MAP)
      } else {
        this.map.setMapType(BMAP_SATELLITE_MAP)
      }
    },
    initMap() {
      const that = this
      const poi = new BMap.Point(119.975223, 29.276122)
      this.map = new BMap.Map('container', { enableMapClick: false })
      this.map.centerAndZoom(poi, 6)
      this.map.enableScrollWheelZoom()
      this.map.disableDoubleClickZoom()
      this.map.setMapStyleV2({
        styleId: 'cd788bc2d84f1292d91e15c718d1a388'
      })

      this.$emit('mapComplete', {
        map: this.map
      })
    },
    // 根据点的数组自动调整缩放级别
    setZoom(bPoints) {
      const view = this.map.getViewport(bPoints)
      const mapZoom = view.zoom
      const centerPoint = view.center
      this.map.centerAndZoom(centerPoint, mapZoom)
      setTimeout(() => (this.mapLoading = false), 1000)
    }
  }
}
</script>
<style>
.anchorBL {
  display: none !important;
}
</style>

<style lang="scss" scoped>
.map {
  width: 100%;
  height: 100%;
  position: relative;
  #container {
    width: 100%;
    height: 100%;
    float: left;
  }
  .mapType-wrapper {
    position: absolute;
    bottom: 0px;
    right: 0;
    cursor: pointer;
    transition-property: width, background-color;
    transition-duration: 0.4s;
    .mapType {
      display: flex;
      .mapTypeCard {
        height: 60px;
        width: 86px;
        border-radius: 2px;
        box-sizing: border-box;
        position: relative;
        cursor: pointer;
        &:first-child {
          margin-right: 10px;
        }
        &:hover,
        &.active {
          border: 1px solid #3385ff;
        }
        &.normal {
          background: url('../../../../images/normal.png') no-repeat;
        }
        &.earth {
          background: url('../../../../images/earth.png') no-repeat;
        }
        .text {
          position: absolute;
          bottom: 0;
          right: 0;
          display: inline-block;
          font-size: 12px;
          height: 18px;
          line-height: 18px;
          width: 38px;
          text-align: center;
          color: #fff;
          border-top-left-radius: 2px;
        }
        &:hover .text,
        &.active .text {
          border: 1px solid #3385ff;
          background-color: #3385ff;
        }
      }
    }
  }
}
</style>
