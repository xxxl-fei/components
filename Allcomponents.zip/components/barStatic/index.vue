<template>
  <div class="talent-bar" :class="timerCount ? 'trans-trans' : ''">
    <div class="count-detail" v-for="(item, index) in newdata" :key="index">
      <div class="country-name">
        <span>{{ item.name }}</span>
      </div>
      <div class="count-backg">
        <div
          class="bar-backg"
          :style="{
            width: item.value
              ? parseInt(
                  ((item.value * 10000) / Math.ceil(max * 10000)) * 100
                ) + '%'
              : 0,
          }"
        >
          <div class="count-bar"></div>
        </div>
      </div>
      <div class="country-count">{{ item.value }}</div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'BarStatic',
  props: {
    data: {
      type: Array,
      default: () => {}
    }
  },
  data() {
    return {
      newdata: [],
      max: 0,
      timerCount: false,
      timer: null
    }
  },
  watch: {
    data() {
      this.getMaxData()
      this.startTimer()
    }
  },
  created() {
    this.getMaxData()
    this.startTimer()
  },
  methods: {
    startTimer() {
      this.getTrans()
    },
    getTrans() {
      this.timerCount = true
      this.timer = setInterval(() => {
        this.timerCount = !this.timerCount
      }, 5000)
    },
    getMaxData() {
      this.newdata = this.data.sort((a, b) => b.value - a.value)
      const arr = [];
      this.data.forEach((dataItem) => {
        arr.push(dataItem.value);
      })
      this.max = Math.max(...arr) / 0.99
    },
    clearTimer() {
      if (this.timer) {
        clearInterval(this.timer)
        this.timer = null
      }
    }
  },
}
</script>
<style lang="scss" scoped>
.talent-bar {
  width: 100%;
  .count-detail {
    display: flex;
    width: 100%;
    margin-bottom: 10px;
    .country-name {
      width: 90px;
      font-size: 14px;
      text-align: right;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .count-backg {
      background: rgba(27, 62, 95, 0.7);
      width: calc(100% - 90px - 60px - 10px);
      margin: 5px 0 0 10px;
      height: 5px;
      .bar-backg {
        height: 100%;
      }
      .count-bar {
        width: 100%;
        background-image: linear-gradient(to right, #00baff, #05fde5);
        height: 100%;
      }
    }
    .country-count {
      width: 60px;
      margin-left: 10px;
      font-size: 14px;
      line-height: 14px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      color: #ffce4a;
      font-weight: 600;
    }
  }
  &.trans-trans {
    .count-bar {
      width: 100%;
      animation: rotateHAHA 2s linear 2s;
      // animation: name duration timing-function delay iteration-count direction fill-mode play-state;
    }
  }
}
@keyframes rotateHAHA {
  0% {
    width: 0%;
  }
  100% {
    width: 100%;
  }
}
</style>
