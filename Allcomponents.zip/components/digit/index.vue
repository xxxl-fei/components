<!--
  LED样式 数字
  需要使用相应的字体-longzhoufeng
  npm install --save vue-count-to
-->
<template>
  <div class="digit">
    <div class="title">{{ title }}</div>
    <p class="led-num">
      <CountTo
        :start-val="parseInt(startVal)"
        :end-val="parseInt(endVal)"
        :duration="3000"
        :separator="separator"
      />
    </p>
  </div>
</template>

<script>

import CountTo from 'vue-count-to'

export default {
  props: {
    num: {
      type: Number,
      default: 0
    },
    separator: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: ''
    }
  },
  components: {
    CountTo
  },
  data() {
    return {
      startVal: 0,
      endVal: 0,
      timer: null
    }
  },
  watch: {
    num() {
      this.refreshData()
    }
  },
  created() {},
  mounted() {
    this.refreshData()
  },
  beforeDestroy() {
    this.clearTimer()
  },
  methods: {
    refreshData() {
      this.clearTimer()
      this.endVal = this.num
      this.timer = setInterval(() => {
        this.startVal = 0
        this.endVal = 0
        setTimeout(() => {
          this.endVal = this.num
        }, 0);
      }, 8000);
    },
    clearTimer() {
      if (this.timer) {
        clearInterval(this.timer)
        this.timer = null
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@font-face {
  font-family: 'DIGITAL';
  src: url("./font/LETS_GO_DIGITAL_REGULAR.ttf");
}
.digit {
  /* fallback for IE */
  .led-num {
    color: #06eefb;
    font-family: 'DIGITAL';
    overflow: hidden;
    font-size: 90px;
  }
  /* gradient text for modern browsers */
  @supports (background-clip: text) {
    .led-num {
      background: linear-gradient(to right, #00ffe4, #d5abff);
      background-clip: text;
      color: transparent;
    }
  }
}
</style>
