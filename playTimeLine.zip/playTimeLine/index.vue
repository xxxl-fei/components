<!-- 播放轴 -->
<template>
    <div class="time-tool">
        <div class="time-tool-bar">
            <div class="slider-container" :style="{width: sliderWidth + 'px'}">
                <div class="tooltip-container" :style="{width:barWidth}">
                    <div class="tooltip-popper"
                        :style="{left:(value/curTime)*parseInt(barWidth)+20+'px'}">
                        <span>{{timeFilter(value)}}</span>
                        <div class="popper-arrow"></div>
                    </div>
                </div>
                <div class="slider-border" :style="{width:barWidth,height:'100%'}">
                    <el-slider
                        v-model="value"
                        :height="barHeight"
                        :max="curTime"
                        :show-tooltip="false"
                        :step="gap"
                        :format-tooltip="timeFilter"
                        @change="timeCallback"
                    >
                    </el-slider>
                </div>
            </div>
        </div>
        <i :class="isplay ? 'el-icon-video-play play-btn':'el-icon-video-pause play-btn'"
            :title="isplay ? '点击播放' : '暂停'"
            @click="go"
            ></i>
        <i class="el-icon-refresh-left play-btn" @click="replay" title="重播"></i>
    </div>
</template>

<script>
export default {
  name: 'Timebar',
  props: {
    // 限制刻度
    limit: {
      type: Boolean,
      default: false
    },
    // 简易模式 (单纯的刻度轴)
    simpleTime: {
      type: Boolean,
      default: false
    },
    // 轴刻度 (默认全天1440分钟)
    splitRange: {
      type: Number,
      default: 1440
    },
    // 步长(默认10分钟)
    gap: {
      type: Number,
      default: 10
    },
    // 播放频率(默认1秒)
    frequence: {
      type: Number,
      default: 1000
    },
    // 刻度(默认24)
    clocks: {
      type: Array,
      default: () => [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
        12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
    },
    // 播放时间范围
    // 某日->某日(能被new date()识别)
    daysRange: {
      type: Array,
      default: () => []
    },
    // 某时->某时(hh:mm)
    timeRange: {
      type: Array,
      default: () => ['14:20', '20:30']
    },
    circle: {
      type: Boolean,
      default: false
    },
    timeFilter: {
      type: Function,
      default: (val) => {
        // 把滑动轴value转成时间
        let hour = Math.floor(val / 60)
        let min = val % 60
        if (hour < 10) hour = `0${hour}`
        min = min < 10 ? `0${min}` : min
        return `${hour}:${min}`
      },
    },
    sliderWidth: {
      type: Number,
      default: 1080
    }
  },
  data() {
    return {
      barHeight: '24px',
      getTimePerMin: '',
      curTime: 0,
      value: 0,
      isplay: true,
      playStatus: null,
      startTime: '',
      endTime: '',
      startDate: '',
      endDate: '',
      dateDiff: 0,
      nowDate: 1,
      dateText: '', // 日期(yyyy-mm-dd)
    }
  },
  watch: {
    isplay(val) {
      if (!val) {
        this.playStatus = setInterval(this.play, this.frequence)
        this.$once('hook:beforeDestroy', () => {
          clearInterval(this.playStatus)
          this.playStatus = null
        })
      } else {
        this.stop()
      }
    },
    timeRange(newArr, oldArr) {
      if (newArr.length > 1 && oldArr.toString() !== newArr.toString()) {
        clearInterval(this.getTimePerMin)
        this.getTimePerMin = null
        this.startTime = newArr[0].split(':')[0] * 60 + +newArr[0].split(':')[1]
        this.endTime = newArr[1].split(':')[0] * 60 + +newArr[1].split(':')[1]
        // 播放起始时间
        this.value = this.startTime
        // 播放终止时间
        if (this.limit) {
          this.curTime = Math.min(this.endTime, this.curTime)
        } else {
          this.curTime = this.endTime
        }
      }
    },
    daysRange(newArr) {
      clearInterval(this.getTimePerMin)
      this.getTimePerMin = null
      this.startDate = this.timeTranslator(newArr[0])
      this.endDate = this.timeTranslator(newArr[1])
      this.getDateDiff(this.startDate.split(' ')[0], this.endDate.split(' ')[0])
      this.value = this.calculatorTimeValue(this.startDate)
      if (this.dateDiff > 1) {
        this.curTime = this.splitRange
      } else {
        this.curTime = this.calculatorTimeValue(this.endDate)
      }
    }
  },
  computed: {
    barWidth() {
      return `${(this.curTime / this.splitRange) * this.sliderWidth}px`
    }
  },
  // 生命周期 - 挂载完成（访问DOM元素）
  mounted() {
    if (this.simpleTime) {
      this.curTime = this.splitRange
    } else {
      this.init()
    }
  },
  destroyed() {
    clearInterval(this.playStatus)
    this.playStatus = null
  },
  // 方法
  methods: {
    init() {
      if (!this.limit) {
        this.curTime = 1440
        return
      }
      this.gettime()
      this.getTimePerMin = setInterval(this.gettime, 1000 * 60) // 每分钟刷新时间轴总长度
      const that = this
      this.$once('hook:beforeDestroy', () => {
        clearInterval(that.getTimePerMin)
        that.getTimePerMin = null
      })
    },
    // 获取最新时间
    gettime() {
      const nowDate = new Date()
      const nowHour = nowDate.getHours() // 获取当前小时数(0-23)
      const nowMin = nowDate.getMinutes()// 获取当前分钟
      this.curTime = nowHour * 60 + nowMin
    },
    // 播放过程
    play() {
      if (this.simpleTime) {
        if (this.value + this.gap <= this.curTime) {
          this.value += this.gap
          this.timeCallback()
        } else if (!this.circle) {
          this.$emit('myEndingEvent', this.timeFilter(this.value), this.value)
          this.stop()
          this.value = this.curTime
        } else {
          this.replay()
          this.isplay = false
        }
        return
      }
      // 不跨天
      if (this.dateDiff < 2) {
        if (this.value + this.gap <= this.curTime) {
          this.value += this.gap
          this.timeCallback()
        } else if (!this.circle) {
          this.$emit('myEndingEvent', this.timeFilter(this.value), this.value)
          this.stop()
          this.value = this.curTime
        } else {
          this.replay()
          this.isplay = false
        }
      } else if (this.nowDate < this.dateDiff) { // 不是最后一天
        if (this.value + this.gap < this.splitRange) {
          this.value += this.gap
          this.timeCallback()
        } else {
          this.nowDate += 1
          const arr = this.dateText.split('-')
          const da = new Date(arr[0], +arr[1] - 1, +arr[2] + 1)
          this.dateText = this.timeTranslator(da).split(' ')[0]
          this.replay()
        }
      } else { // 最后一天
        this.curTime = this.calculatorTimeValue(this.endDate)
        if (this.value + this.gap <= this.curTime) {
          this.value += this.gap
          this.timeCallback()
        } else if (!this.circle) {
          this.$emit('myEndingEvent', this.timeFilter(this.value), this.value)
          this.stop()
          this.value = this.curTime
        } else {
          this.curTime = this.splitRange
          this.value = this.calculatorTimeValue(this.startDate)
          this.dateText = this.startDate.split(' ')[0]
          this.timeCallback()
          this.nowDate = 1
        }
      }
    },
    // 暂停
    stop() {
      this.isplay = true
      clearInterval(this.playStatus)
    },
    // 播放回调
    timeCallback() {
      this.$emit('myIntervalEvent', this.timeFilter(this.value), this.value, this.dateText)
    },
    // 播放
    go() {
      this.isplay = !this.isplay
      if (!this.isplay && (this.value + this.gap > this.curTime)) {
        this.value = this.startTime || 0
      }
    },
    // 重播
    replay() {
      // 跨天播放的非第一天
      if (this.nowDate > 1) {
        const end = this.calculatorTimeValue(this.endDate)
        if (this.value + this.gap === this.splitRange) {
          this.value = 0
        } else {
          // 非最后一天从gap开始播放， 最后一天取终点值和gap值的小值
          this.value = this.nowDate === this.dateDiff ? Math.min(this.gap, end) : this.gap
        }
        this.timeCallback()
      } else {
        this.value = this.startTime === '' ? 0 : this.startTime
        this.isplay = true
      }
    },
    // new Date -> yyyy-mm-dd hh:mm
    timeTranslator(time) {
      const myDate = new Date(time)
      const month = myDate.getMonth() + 1 < 10 ? `0${myDate.getMonth() + 1}` : myDate.getMonth() + 1
      const day = myDate.getDate() < 10 ? `0${myDate.getDate()}` : myDate.getDate()
      const hour = myDate.getHours() < 10 ? `0${myDate.getHours()}` : myDate.getHours()
      const min = myDate.getMinutes() < 10 ? `0${myDate.getMinutes()}` : myDate.getMinutes()
      const date = `${myDate.getFullYear()}-${month}-${day} ${hour}:${min}`
      return date
    },
    // 计算天数
    getDateDiff(date1, date2) {
      const arr1 = date1.split('-')
      const arr2 = date2.split('-')
      this.dateText = date1
      const d1 = new Date(arr1[0], arr1[1] - 1, arr1[2])
      const d2 = new Date(arr2[0], arr2[1] - 1, arr2[2])
      this.dateDiff = (d2.getTime() - d1.getTime()) / (1000 * 3600 * 24) + 1
    },
    // make一个0~24的数组
    makeNumberArr(num) {
      let i = 0
      const arr = []
      while (i < num) {
        arr.push(i)
        i += 1
      }
      return arr
    },
    // hh:mm -> hh + mm*60
    calculatorTimeValue(str) {
      return str.split(' ')[1].split(':')[0] * 60 + +str.split(' ')[1].split(':')[1]
    }
  },
}
</script>

<style scoped lang="scss">
    .time-tool{
      overflow: hidden;
      .time-tool-bar{
        margin-right: 20px;
        padding: 37px 0 20px 10px;
        position:relative;
        float: left;
        .slider-container{
          margin-left:30px;
          background:#323641;
          border-radius:12px;
          z-index:2;
          height: 14px;
          & /deep/ .el-slider{
            height: 100%;
          }
          & /deep/ .el-slider__runway{
            background: #e4e7ed;
            margin: 0;
            height: 14px;
            border-radius: 10px;
            .el-slider__bar{
              height: 14px;
              border-radius: 10px;
              background-image: linear-gradient(to right, #5ba3f4, #33b4f7) !important;
            }
            .el-slider__button-wrapper{
              top: -12px
            }
          }
          .tooltip-popper{
            transform-origin: center bottom;
            z-index: 1;
            position: absolute;
            top: 8px;
            left:20px;
            background: #3498db;
            color: #FFF;
            border-radius: 4px;
            padding: 2px 5px;
            z-index: 2000;
            font-size: 14px;
            margin-bottom: 12px;
            .popper-arrow{
              left: 19.5px;
              bottom: -6px;
              border-top-color: #3498db;
              border-bottom-width: 0;
              border-width: 6px;
              &::after{
                position: absolute;
                display: block;
                width: 0;
                height: 0;
                border-color: transparent;
                border-style: solid;
                bottom: -10px;
                margin-left: 10px;
                border-top-color: #3498db;
                border-bottom-width: 0;
                content: " ";
                border-width: 5px;
              }
            }
          }
        }
      }
      .play-btn{
        // transform: translate(30%, 40%);
        cursor:pointer;
        color: #000;
        font-size: 50px;
      }
    }
</style>
