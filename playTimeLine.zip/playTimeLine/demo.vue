<template>
  <div>
    <div class="app-container">
      <span>步长:</span>
      <el-select v-model="value" placeholder="请选择">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        </el-option>
      </el-select>
      <span>播放速率:</span>
      <el-select v-model="value4" placeholder="请选择">
        <el-option
          v-for="item in options1"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        </el-option>
      </el-select>
      <span> 循环播放</span>
      <el-switch
        v-model="value3"
        active-color="#13ce66"
        inactive-color="#ff4949">
      </el-switch>
      <div style="height:20px;"></div>
      <time-line
        @myIntervalEvent="loopEvent"
        @myEndingEvent="endEvent"
        :frequence="value4"
        :gap="value"
        :circle="value3"
      ></time-line>

      <div style="height:20px;"></div>
      <el-time-picker
        is-range
        v-model="value2"
        range-separator="至"
        start-placeholder="开始时间"
        end-placeholder="结束时间"
        placeholder="选择时间范围"
        format="HH:mm">
      </el-time-picker>
      <div style="height:20px;"></div>
      <time-line
        @myIntervalEvent="loopEvent"
        :frequence="value4"
        :gap="value"
        :timeRange="tttfilter(value2)"
        :circle="value3"
      ></time-line>

      <br>
      <p class="current-time">
        当前播放时间:
        <span style="display:inline-block;width: 400px;">{{timeText}}</span>
      </p>
      <el-date-picker
        v-model="value1"
        type="datetimerange"
        range-separator="至"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        format="yyyy-MM-dd HH:mm">
      </el-date-picker>
      <div style="height:20px;"></div>
      <time-line
        @myIntervalEvent="loopEvent"
        :frequence="value4"
        :gap="value"
        :daysRange="value1"
        :circle="value3"
      ></time-line>
    </div>
  </div>
</template>

<script>
import Timeline from '@/views/dashboard/components/playTimeLine'

export default {
  name: 'DemoPage',
  components: {
    'time-line': Timeline
  },
  data() {
    return {
      timeText: '',
      options: [{
        label: '1分钟',
        value: 1
      }, {
        label: '5分钟',
        value: 5
      }, {
        label: '10分钟',
        value: 10
      }, {
        label: '30分钟',
        value: 30
      }, {
        label: '1小时',
        value: 60
      }],
      options1: [{
        label: '0.5秒',
        value: 500
      }, {
        label: '1秒',
        value: 1000
      }, {
        label: '2秒',
        value: 2000
      }, {
        label: '3秒',
        value: 3000
      }, {
        label: '5秒',
        value: 5000
      }],
      value: 10,
      value1: [],
      value2: [new Date(), new Date()],
      value3: false,
      value4: 1000,
    }
  },
  methods: {
    loopEvent(time, index, date) {
      console.log(date, time, index)
      this.timeText = date
    },
    endEvent(time) {
      console.warn(`播放结束:${time}`)
    },
    tttfilter(arr) {
      let i = 0
      const brr = []
      while (i < 2) {
        const myDate = arr[i]
        const hour = myDate.getHours() < 10 ? `0${myDate.getHours()}` : myDate.getHours()
        const min = myDate.getMinutes() < 10 ? `0${myDate.getMinutes()}` : myDate.getMinutes()
        brr.push(`${hour}:${min}`)
        i += 1
      }
      return brr
    }
  }
}
</script>

<style scoped>
  .app-container {
    width: 80%;
    margin: 0 auto;
    padding-top: 120px;
  }

  .img-style {
    width: auto;
    height: auto;
    max-width: 100%;
    max-height: 100%;
  }

  .current-time{
    margin-bottom:20px;
    font-size: 20px;
    color: #000;
    display: inline-block;
  }
</style>
